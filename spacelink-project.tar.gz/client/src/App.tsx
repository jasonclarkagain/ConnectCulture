import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { useAuth } from "@/hooks/useAuth";
import Landing from "@/pages/landing";
import Home from "@/pages/home";
import Profile from "@/pages/profile";
import Files from "@/pages/files";
import Messages from "@/pages/messages";
import Customize from "@/pages/customize";
import Apps from "@/pages/apps";
import Health from "@/pages/health";
import Safety from "@/pages/safety";
import Privacy from "@/pages/privacy";
import Civic from "@/pages/civic";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <Route path="/" component={Home} />
          <Route path="/profile/:username?" component={Profile} />
          <Route path="/files" component={Files} />
          <Route path="/messages" component={Messages} />
          <Route path="/apps" component={Apps} />
          <Route path="/health" component={Health} />
          <Route path="/safety" component={Safety} />
          <Route path="/privacy" component={Privacy} />
          <Route path="/civic" component={Civic} />
          <Route path="/customize" component={Customize} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
